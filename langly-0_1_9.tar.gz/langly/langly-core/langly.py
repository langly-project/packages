#!/opt/Langly/bin/python

import argparse
import os
import requests
import subprocess
import yaml
from datetime import datetime
from rich import print
from rich.panel import Panel

def validate_playbook(file_path):
    try:
        with open(file_path, 'r') as f:
            yaml.safe_load(f)
        print(Panel.fit(f":white_check_mark: [bold green]YAML válido[/bold green]\nArquivo: {file_path}"))
    except yaml.YAMLError as e:
        print(Panel.fit(f":x: [bold red]Erro de sintaxe YAML:[/bold red] {e}"))
    except FileNotFoundError:
        print(Panel.fit(f":warning: [bold yellow]Arquivo não encontrado:[/bold yellow] {file_path}"))

def explain_task(task_name):
    explicacoes = {
        "apt": "O módulo 'apt' é usado para gerenciar pacotes em sistemas baseados em Debian.",
        "yum": "O módulo 'yum' é usado para instalar, atualizar e remover pacotes em sistemas RHEL/CentOS.",
        "copy": "O módulo 'copy' copia arquivos do controlador para os hosts gerenciados.",
        "template": "O módulo 'template' usa Jinja2 para gerar arquivos dinâmicos antes de copiá-los para o destino.",
        "user": "O módulo 'user' é utilizado para gerenciar contas de usuários em sistemas Linux, permitindo criar, modificar ou remover usuários, definir senhas e ajustar diretórios home e shells."
    }
    explicacao = explicacoes.get(task_name, "Nenhuma explicação encontrada para este módulo.")
    print(Panel.fit(f"[bold cyan]{task_name}[/bold cyan]: {explicacao}"))

def optimize_inventory():
    print(Panel.fit(":gear: [bold green]Função de otimização de inventário em construção...[/bold green]"))

def generate_and_push(prompt, repo_path="/opt/langly-core/playbooks", push=False):
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        print(Panel.fit("[bold red]Erro:[/bold red] Variável de ambiente GROQ_API_KEY não encontrada."))
        return

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    payload = {
        "model": "meta-llama/llama-4-scout-17b-16e-instruct",
        "messages": [
            {"role": "system", "content": "Gere apenas um playbook Ansible."},
            {"role": "user", "content": prompt}
        ]
    }

    try:
        response = requests.post("https://api.groq.com/openai/v1/chat/completions", json=payload, headers=headers)
        response.raise_for_status()
        playbook = response.json()["choices"][0]["message"]["content"]
    except Exception as e:
        print(Panel.fit(f"[bold red]Erro na requisição:[/bold red] {e}"))
        return

    os.makedirs(repo_path, exist_ok=True)
    filename = f"{repo_path}/playbook_{datetime.now().strftime('%Y%m%d_%H%M%S')}.yml"
    with open(filename, 'w') as f:
        f.write(playbook)

    print(Panel.fit(f"[bold green]Playbook salvo em:[/bold green] {filename}"))

    if push:
        try:
            subprocess.run(["git", "add", filename], cwd=repo_path, check=True)
            subprocess.run(["git", "commit", "-m", f"Playbook gerado via IA: {prompt}"], cwd=repo_path, check=True)
            subprocess.run(["git", "push"], cwd=repo_path, check=True)
            print(Panel.fit("[bold cyan]Commit e push realizados com sucesso![/bold cyan]"))
        except subprocess.CalledProcessError as e:
            print(Panel.fit(f"[bold red]Erro ao fazer push:[/bold red] {e}"))

def main():
    parser = argparse.ArgumentParser(prog="langly", description="Langly - Copiloto de automação Ansible")
    subparsers = parser.add_subparsers(dest='command')

    # validate
    parser_validate = subparsers.add_parser('validate', help='Valida um playbook YAML')
    parser_validate.add_argument('file', help='Caminho para o arquivo playbook')

    # explain
    parser_explain = subparsers.add_parser('explain', help='Explica um módulo do Ansible')
    parser_explain.add_argument('task', help='Nome do módulo Ansible (ex: copy, yum, apt)')

    # optimize
    subparsers.add_parser('optimize', help='Otimiza um inventário Ansible (em breve)')

    # generate
    parser_generate = subparsers.add_parser('generate', help='Gera um playbook com base em prompt')
    parser_generate.add_argument('prompt', help='Prompt para gerar o playbook')
    parser_generate.add_argument('--push', action='store_true', help='Faz push automático para o Git')

    args = parser.parse_args()

    if args.command == 'validate':
        validate_playbook(args.file)
    elif args.command == 'explain':
        explain_task(args.task)
    elif args.command == 'optimize':
        optimize_inventory()
    elif args.command == 'generate':
        generate_and_push(args.prompt, push=args.push)
    else:
        parser.print_help()

if __name__ == '__main__':
    main()

