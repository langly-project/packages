#!/bin/bash

while true; do
    if [[ -f /var/www/result/reset ]]; then
        CONTENT=$(cat /var/www/result/reset)
        if [[ "$CONTENT" == "1" ]]; then
            > /var/www/result/result
            rm -f /var/www/result/reset
            echo "Resultado limpo por sinal externo com valor 1."
        fi
    fi

    sleep 2
done
