<?php
$arquivoResultado = "/var/www/result/result";
if (file_exists($arquivoResultado)) {
    echo htmlspecialchars(file_get_contents($arquivoResultado));
} else {
    echo "Sem resultado ainda.";
}
?>
