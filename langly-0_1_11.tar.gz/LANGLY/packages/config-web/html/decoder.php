<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Langly</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background-color: #fafafa;
        }
        h1 {
            color: #222;
        }
        textarea {
            width: 100%;
            font-size: 16px;
            padding: 10px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }
        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }
        hr {
            margin: 20px 0;
        }
        pre {
            background: #f4f4f4;
            padding: 15px;
            border: 1px solid #ccc;
            white-space: pre-wrap;
        }
    </style>

    <script>
        function atualizarResultado() {
            fetch('result.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('resultado').innerHTML = '<pre>' + data + '</pre>';
                });
        }

        // Atualiza a cada 5 segundos
        setInterval(atualizarResultado, 5000);

        // Atualiza imediatamente ao carregar a página
        window.onload = atualizarResultado;
    </script>
</head>
<body>

<h1>Langly</h1>

<form method="post">
    <textarea name="entrada" rows="10" placeholder="Como quer sua playbook?"></textarea><br>
    <button type="submit" name="acao" value="decode">Decode</button>
</form>

<hr>

<h2>Result:</h2>
<div id="resultado"><pre>Carregando...</pre></div>

<?php
// Grava a pergunta
$arquivoPergunta = "/var/www/question/question";
if ($_SERVER["REQUEST_METHOD"] === "POST" && $_POST["acao"] === "decode" && !empty($_POST["entrada"])) {
    file_put_contents($arquivoPergunta, $_POST["entrada"]);
    header("Location: " . $_SERVER["PHP_SELF"]);
    exit();
}
?>


<form method="POST" action="clean.php">
  <button type="submit">Clear Result</button>
</form>

</body>
</html>

