<?php
$resetFile = '/var/www/result/reset';

if (file_put_contents($resetFile, "1") !== false) {
    header("Location: decoder.php?clean=ok");
    exit;
} else {
    header("Location: decoder.php?clean=fail");
    exit;
}
?>
