#!/bin/bash

# ─────────────────────────────────────────────────────────────
# Langly Web Installer – Oracle Linux 8
# Instala Apache + PHP 7.2, desabilita firewalld e SELinux
# ─────────────────────────────────────────────────────────────


echo "[1/6] 🔥 Desabilitando firewalld..."
sudo systemctl stop firewalld
sudo systemctl disable firewalld

echo "[1/6/1] 🔥 Definindo hostname langly..."
hostnamectl set-hostname langly

echo "[2/6] 🔐 Configurando SELinux (modo permissivo agora)..."
sudo setenforce 0

echo "[3/6] ❌ Desabilitando SELinux permanentemente..."
sudo sed -i 's/^SELINUX=.*/SELINUX=disabled/' /etc/selinux/config

echo "[4/6] 📦 Instalando Apache (httpd)..."
sudo dnf install -y httpd

echo "[5/6] 💻 Instalando PHP 7.2 e módulos..."
sudo dnf module reset php -y
sudo dnf module enable php:7.2 -y
sudo dnf install -y php php-cli php-common

echo "[6/6] 🚀 Iniciando e habilitando Apache..."
sudo systemctl enable httpd
sudo systemctl start httpd

echo "[6/6.1] 🚀 Iniciando copia de configs php..."
cd /tmp/LANGLY/
cp -rv packages/config-web/result /var/www/
cp -rv packages/config-web/question /var/www/
cp -rv packages/config-web/key /var/www/
cp -rv packages/config-web/html /var/www/

echo "[6/6.2] 🚀 Iniciando copia de exec service..."
cp -rv packages/langly-web-of-opt/* /opt/

echo "[6/6.3] 🚀 Iniciando copia de service systemd e enable o mesmo..."
cp -rv packages/systemd/* /etc/systemd/system/
systemctl daemon-reexec
systemctl daemon-reload
systemctl enable --now langly.service
systemctl restart langly.service
systemctl enable --now watch-reset.service
systemctl restart watch-reset.service
systemctl status langly.service

cd /var/www/
chown -R apache:apache result
chown -R apache:apache question
chown -R apache:apache key
chown -R apache:apache html

# Para o Nginx
sudo systemctl stop nginx
sudo systemctl disable nginx

# Inicia o Apache
sudo systemctl enable --now httpd

echo ""
echo "✅ Instalação concluída!"
echo "🌐 Acesse: http://<SEU_IP>/"
echo "⚠️ Reinicie o sistema para aplicar desativação definitiva do SELinux."

