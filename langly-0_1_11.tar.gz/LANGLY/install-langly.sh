#!/bin/bash

set -e

PYTHON_VERSION=3.11.9
PY_PREFIX="/opt/python3.11"

echo "🔧 Instalando Langly CLI..."

SRC_DIR="/tmp/LANGLY"
DEST_VENV="/opt/Langly"
DEST_CORE="/opt/langly-core"

# Copia arquivos necessários
echo "📁 Copiando código do Langly..."
cp -r "$SRC_DIR/langly-core" "$DEST_CORE"

echo "⚙️ Instalando comando 'langly' CLI..."

# Instala o gerador se quiser como outro comando
cp "$SRC_DIR/langly-generator.sh" /usr/local/bin/langly
chmod +x /usr/local/bin/langly

echo "===> Instalando dependências..."
dnf groupinstall -y "Development Tools"
dnf install -y gcc openssl-devel bzip2-devel libffi-devel wget make zlib-devel readline-devel sqlite-devel xz-devel tk-devel gdbm-devel ncurses-devel

echo "===> Baixando o Python $PYTHON_VERSION (usando IPv4)..."
cd /usr/src
wget -4 https://www.python.org/ftp/python/${PYTHON_VERSION}/Python-${PYTHON_VERSION}.tgz
tar xzf Python-${PYTHON_VERSION}.tgz
cd Python-${PYTHON_VERSION}

echo "===> Compilando Python em ${PY_PREFIX}..."
./configure --enable-optimizations --prefix=$PY_PREFIX
make -j$(nproc)
make altinstall

echo "===> Instalando dependências do Langly..."
$PY_PREFIX/bin/pip3.11 install --upgrade pip
$PY_PREFIX/bin/pip3.11 install requests pyyaml rich

echo "===> Registrando python3.11 como padrão com update-alternatives..."
update-alternatives --install /usr/bin/python python ${PY_PREFIX}/bin/python3.11 1
update-alternatives --install /usr/bin/python3 python3 ${PY_PREFIX}/bin/python3.11 1
update-alternatives --set python ${PY_PREFIX}/bin/python3.11
update-alternatives --set python3 ${PY_PREFIX}/bin/python3.11

echo "===> Python 3.11 está agora como padrão do sistema."
echo
echo "✅ Versão atual:"
python --version
python3 --version

echo ""
echo "✅ [Langly] Python $PYTHON_VERSION instalado com sucesso!"
echo ""
echo "Use o comando: langly generate \"algo que o playbook deve fazer\""
