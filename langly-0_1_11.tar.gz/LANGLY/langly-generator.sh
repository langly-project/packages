#!/bin/bash

# GROQ_API_KEY
export GROQ_API_KEY="CHAVE"

clear
echo ""
echo "========================== LANGLY ================================="
echo ""
read -p "Como deseja sua Playbook? : " prompt

# Executa diretamente o CLI Python, evitando loop
/opt/python3.11/bin/python3.11 /opt/langly-core/langly.py generate "$prompt"
