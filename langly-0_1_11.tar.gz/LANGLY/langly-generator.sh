#!/bin/bash

# GROQ_API_KEY
export GROQ_API_KEY="Você pode gerar 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"

clear
echo ""
echo "========================== LANGLY ================================="
echo ""
read -p "Como deseja sua Playbook? : " prompt

# Executa diretamente o CLI Python, evitando loop
/opt/python3.11/bin/python3.11 /opt/langly-core/langly.py generate "$prompt"
